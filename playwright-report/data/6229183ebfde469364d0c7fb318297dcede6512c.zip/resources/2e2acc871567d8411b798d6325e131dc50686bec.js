window._comscore=window._comscore||[],window._comscore.push({c1:"2",c2:"9576127"}),function(){var e=document.createElement("script"),c=document.getElementsByTagName("script")[0];e.async=!0,e.src=(document.location.protocol=="https:"?"https://sb":"http://b")+".scorecardresearch.com/beacon.js",c.parentNode.insertBefore(e,c)}();

//# sourceMappingURL=comscore.ext.1fe27c.js.map